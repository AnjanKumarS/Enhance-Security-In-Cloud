import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.action.Database;

@WebServlet("/DownloadServlet")
public class DownloadServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/octet-stream");
        
        // Retrieve parameters from request
        String filename = request.getParameter("filename");
        String owner = request.getParameter("owner");
        
        // Query database to get file data
        try {
            Connection con = Database.getConnection();
            PreparedStatement pstmt = con.prepareStatement("SELECT file FROM files WHERE filename=? AND owner=?");
            pstmt.setString(1, filename);
            pstmt.setString(2, owner);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                InputStream inputStream = rs.getBinaryStream("file");
                OutputStream outputStream = response.getOutputStream();
                byte[] buffer = new byte[4096];
                int bytesRead = -1;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
                inputStream.close();
                outputStream.close();
            } else {
                response.getWriter().println("File not found");
            }
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "File Download Servlet";
    }
}
